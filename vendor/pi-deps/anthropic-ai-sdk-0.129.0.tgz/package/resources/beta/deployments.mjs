import { APIResource } from "../../core/resource.mjs";
import { PageCursor } from "../../core/pagination.mjs";
import { buildHeaders } from "../../internal/headers.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Deployments extends APIResource {
    /**
     * Create Deployment
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeployment =
     *   await client.beta.deployments.create({
     *     agent: 'string',
     *     environment_id: 'x',
     *     initial_events: [
     *       {
     *         content: [
     *           {
     *             text: 'Where is my order #1234?',
     *             type: 'text',
     *           },
     *         ],
     *         type: 'user.message',
     *       },
     *     ],
     *     name: 'x',
     *   });
     * ```
     */
    create(params, options) {
        const { betas, workspace_id, ...body } = params;
        return this._client.post('/v1/deployments?beta=true', {
            body,
            ...options,
            headers: buildHeaders([
                {
                    'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
        });
    }
    /**
     * Get Deployment
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeployment =
     *   await client.beta.deployments.retrieve(
     *     'depl_011CZkZcDH3vPqd7xnEfwTai',
     *   );
     * ```
     */
    retrieve(deploymentID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.get(path `/v1/deployments/${deploymentID}?beta=true`, {
            ...options,
            headers: buildHeaders([
                {
                    'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
        });
    }
    /**
     * Update Deployment
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeployment =
     *   await client.beta.deployments.update(
     *     'depl_011CZkZcDH3vPqd7xnEfwTai',
     *   );
     * ```
     */
    update(deploymentID, params, options) {
        const { betas, workspace_id, ...body } = params;
        return this._client.post(path `/v1/deployments/${deploymentID}?beta=true`, {
            body,
            ...options,
            headers: buildHeaders([
                {
                    'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
        });
    }
    /**
     * List Deployments
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsDeployment of client.beta.deployments.list()) {
     *   // ...
     * }
     * ```
     */
    list(params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList('/v1/deployments?beta=true', (PageCursor), {
            query,
            ...options,
            headers: buildHeaders([
                {
                    'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
        });
    }
    /**
     * Archive Deployment
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeployment =
     *   await client.beta.deployments.archive(
     *     'depl_011CZkZcDH3vPqd7xnEfwTai',
     *   );
     * ```
     */
    archive(deploymentID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.post(path `/v1/deployments/${deploymentID}/archive?beta=true`, {
            ...options,
            headers: buildHeaders([
                {
                    'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
        });
    }
    /**
     * Pause Deployment
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeployment =
     *   await client.beta.deployments.pause(
     *     'depl_011CZkZcDH3vPqd7xnEfwTai',
     *   );
     * ```
     */
    pause(deploymentID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.post(path `/v1/deployments/${deploymentID}/pause?beta=true`, {
            ...options,
            headers: buildHeaders([
                {
                    'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
        });
    }
    /**
     * Run Deployment Now
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeploymentRun =
     *   await client.beta.deployments.run(
     *     'depl_011CZkZcDH3vPqd7xnEfwTai',
     *   );
     * ```
     */
    run(deploymentID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.post(path `/v1/deployments/${deploymentID}/run?beta=true`, {
            ...options,
            headers: buildHeaders([
                {
                    'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
        });
    }
    /**
     * Unpause Deployment
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeployment =
     *   await client.beta.deployments.unpause(
     *     'depl_011CZkZcDH3vPqd7xnEfwTai',
     *   );
     * ```
     */
    unpause(deploymentID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.post(path `/v1/deployments/${deploymentID}/unpause?beta=true`, {
            ...options,
            headers: buildHeaders([
                {
                    'anthropic-beta': [...(betas ?? []), 'managed-agents-2026-04-01'].toString(),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
        });
    }
}
//# sourceMappingURL=deployments.mjs.map