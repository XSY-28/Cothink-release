import { APIResource } from "../../core/resource.mjs";
import * as BetaAPI from "./beta.mjs";
import * as AgentsAPI from "./agents/agents.mjs";
import { APIPromise } from "../../core/api-promise.mjs";
import { PageCursor, type PageCursorParams, PagePromise } from "../../core/pagination.mjs";
import { RequestOptions } from "../../internal/request-options.mjs";
export declare class DeploymentRuns extends APIResource {
    /**
     * Get Deployment Run
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeploymentRun =
     *   await client.beta.deploymentRuns.retrieve(
     *     'deployment_run_id',
     *   );
     * ```
     */
    retrieve(deploymentRunID: string, params?: DeploymentRunRetrieveParams | null | undefined, options?: RequestOptions): APIPromise<BetaManagedAgentsDeploymentRun>;
    /**
     * List Deployment Runs
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsDeploymentRun of client.beta.deploymentRuns.list()) {
     *   // ...
     * }
     * ```
     */
    list(params?: DeploymentRunListParams | null | undefined, options?: RequestOptions): PagePromise<BetaManagedAgentsDeploymentRunsPageCursor, BetaManagedAgentsDeploymentRun>;
}
export type BetaManagedAgentsDeploymentRunsPageCursor = PageCursor<BetaManagedAgentsDeploymentRun>;
/**
 * The deployment's agent was archived.
 */
export interface BetaManagedAgentsAgentArchivedRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'agent_archived_error';
}
/**
 * A persistent, append-only record of a single deployment execution. Records
 * session creation success or failure — no session lifecycle tracking.
 */
export interface BetaManagedAgentsDeploymentRun {
    /**
     * Unique identifier for this run (`drun_...`).
     */
    id: string;
    /**
     * Snapshot of the agent at fire time. Always fully resolved — deployments pin
     * agent + version.
     */
    agent: AgentsAPI.BetaManagedAgentsAgentReference;
    /**
     * Time this run record was persisted.
     */
    created_at: string;
    /**
     * ID of the deployment that produced this run.
     */
    deployment_id: string;
    /**
     * Populated on creation failure. Null on success. Exactly one of `session_id` or
     * `error` is non-null.
     */
    error: BetaManagedAgentsEnvironmentArchivedRunError | BetaManagedAgentsAgentArchivedRunError | BetaManagedAgentsEnvironmentNotFoundRunError | BetaManagedAgentsVaultNotFoundRunError | BetaManagedAgentsVaultArchivedRunError | BetaManagedAgentsFileNotFoundRunError | BetaManagedAgentsMemoryStoreArchivedRunError | BetaManagedAgentsSkillNotFoundRunError | BetaManagedAgentsSessionResourceNotFoundRunError | BetaManagedAgentsWorkspaceArchivedRunError | BetaManagedAgentsOrganizationDisabledRunError | BetaManagedAgentsSessionRateLimitedRunError | BetaManagedAgentsSessionCreationRejectedRunError | BetaManagedAgentsUnknownRunError | BetaManagedAgentsSelfHostedResourcesUnsupportedRunError | BetaManagedAgentsMCPEgressBlockedRunError | null;
    /**
     * Populated on success. Null on creation failure. Exactly one of `session_id` or
     * `error` is non-null.
     */
    session_id: string | null;
    /**
     * What triggered this run and trigger-specific metadata.
     */
    trigger_context: BetaManagedAgentsTriggerContext;
    type: 'deployment_run';
}
/**
 * The deployment's environment was archived.
 */
export interface BetaManagedAgentsEnvironmentArchivedRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'environment_archived_error';
}
/**
 * The deployment's environment no longer exists.
 */
export interface BetaManagedAgentsEnvironmentNotFoundRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'environment_not_found_error';
}
/**
 * A file resource referenced by the deployment no longer exists.
 */
export interface BetaManagedAgentsFileNotFoundRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'file_not_found_error';
}
/**
 * The run was started manually by creating a session directly against the
 * deployment.
 */
export interface BetaManagedAgentsManualTriggerContext {
    type: 'manual';
}
/**
 * An MCP server host used by the deployment's agent is blocked by the
 * environment's network policy.
 */
export interface BetaManagedAgentsMCPEgressBlockedRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'mcp_egress_blocked_error';
}
/**
 * A memory store referenced by the deployment is archived.
 */
export interface BetaManagedAgentsMemoryStoreArchivedRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'memory_store_archived_error';
}
/**
 * The deployment's organization is disabled.
 */
export interface BetaManagedAgentsOrganizationDisabledRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'organization_disabled_error';
}
/**
 * The run was fired by the deployment's cron schedule.
 */
export interface BetaManagedAgentsScheduleTriggerContext {
    /**
     * The UTC instant at which the cron expression matched in the configured timezone,
     * before jitter is applied. At most one run is recorded per (`deployment_id`,
     * `scheduled_at`) pair.
     */
    scheduled_at: string;
    type: 'schedule';
}
/**
 * The deployment configures resources, but its environment is self-hosted and
 * cannot mount them.
 */
export interface BetaManagedAgentsSelfHostedResourcesUnsupportedRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'self_hosted_resources_unsupported_error';
}
/**
 * The session create request was rejected with a non-retryable validation error.
 */
export interface BetaManagedAgentsSessionCreationRejectedRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'session_creation_rejected_error';
}
/**
 * Session creation was rejected due to rate limiting. The schedule keeps firing;
 * subsequent runs may succeed.
 */
export interface BetaManagedAgentsSessionRateLimitedRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'session_rate_limited_error';
}
/**
 * A referenced resource no longer exists and its kind was not reported.
 */
export interface BetaManagedAgentsSessionResourceNotFoundRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'session_resource_not_found_error';
}
/**
 * A skill referenced by the deployment's agent no longer exists.
 */
export interface BetaManagedAgentsSkillNotFoundRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'skill_not_found_error';
}
/**
 * Describes what triggered a deployment run, with trigger-specific metadata.
 */
export type BetaManagedAgentsTriggerContext = BetaManagedAgentsScheduleTriggerContext | BetaManagedAgentsManualTriggerContext;
/**
 * What triggered a deployment run.
 *
 * - `schedule` - The run was fired by the deployment's cron schedule.
 * - `manual` - The run was started manually by creating a session directly against
 *   the deployment.
 */
export type BetaManagedAgentsTriggerType = 'schedule' | 'manual';
/**
 * An unknown or unexpected error caused the run to fail. A fallback variant;
 * clients that do not recognize a new error type can match on message alone.
 */
export interface BetaManagedAgentsUnknownRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'unknown_error';
}
/**
 * A vault referenced by the deployment is archived.
 */
export interface BetaManagedAgentsVaultArchivedRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'vault_archived_error';
}
/**
 * A vault referenced by the deployment no longer exists.
 */
export interface BetaManagedAgentsVaultNotFoundRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'vault_not_found_error';
}
/**
 * The deployment's workspace was archived.
 */
export interface BetaManagedAgentsWorkspaceArchivedRunError {
    /**
     * Human-readable error description.
     */
    message: string;
    type: 'workspace_archived_error';
}
export interface DeploymentRunRetrieveParams {
    /**
     * Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
    /**
     * Optional header to select the Workspace for this request. The value is a
     * Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).
     *
     * Only needed for credentials that can act on more than one Workspace. A
     * credential that belongs to a specific Workspace may omit it; if sent, it must
     * match that Workspace.
     */
    workspace_id?: string;
}
export interface DeploymentRunListParams extends PageCursorParams {
    /**
     * Query param: Return runs created strictly after this time (exclusive).
     */
    'created_at[gt]'?: string;
    /**
     * Query param: Return runs created at or after this time (inclusive).
     */
    'created_at[gte]'?: string;
    /**
     * Query param: Return runs created strictly before this time (exclusive).
     */
    'created_at[lt]'?: string;
    /**
     * Query param: Return runs created at or before this time (inclusive).
     */
    'created_at[lte]'?: string;
    /**
     * Query param: Filter to a specific deployment. Omit to list across all
     * deployments in the workspace. Filtering by a non-existent `deployment_id`
     * returns 200 with empty data.
     */
    deployment_id?: string;
    /**
     * Query param: Filter: true for runs with non-null `error`, false for runs with
     * non-null `session_id`. Omit for all.
     */
    has_error?: boolean;
    /**
     * Query param: Filter runs by what triggered them. Omit to return all runs.
     */
    trigger_type?: BetaManagedAgentsTriggerType;
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
    /**
     * Header param: Optional header to select the Workspace for this request. The
     * value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).
     *
     * Only needed for credentials that can act on more than one Workspace. A
     * credential that belongs to a specific Workspace may omit it; if sent, it must
     * match that Workspace.
     */
    workspace_id?: string;
}
export declare namespace DeploymentRuns {
    export { type BetaManagedAgentsAgentArchivedRunError as BetaManagedAgentsAgentArchivedRunError, type BetaManagedAgentsDeploymentRun as BetaManagedAgentsDeploymentRun, type BetaManagedAgentsEnvironmentArchivedRunError as BetaManagedAgentsEnvironmentArchivedRunError, type BetaManagedAgentsEnvironmentNotFoundRunError as BetaManagedAgentsEnvironmentNotFoundRunError, type BetaManagedAgentsFileNotFoundRunError as BetaManagedAgentsFileNotFoundRunError, type BetaManagedAgentsManualTriggerContext as BetaManagedAgentsManualTriggerContext, type BetaManagedAgentsMCPEgressBlockedRunError as BetaManagedAgentsMCPEgressBlockedRunError, type BetaManagedAgentsMemoryStoreArchivedRunError as BetaManagedAgentsMemoryStoreArchivedRunError, type BetaManagedAgentsOrganizationDisabledRunError as BetaManagedAgentsOrganizationDisabledRunError, type BetaManagedAgentsScheduleTriggerContext as BetaManagedAgentsScheduleTriggerContext, type BetaManagedAgentsSelfHostedResourcesUnsupportedRunError as BetaManagedAgentsSelfHostedResourcesUnsupportedRunError, type BetaManagedAgentsSessionCreationRejectedRunError as BetaManagedAgentsSessionCreationRejectedRunError, type BetaManagedAgentsSessionRateLimitedRunError as BetaManagedAgentsSessionRateLimitedRunError, type BetaManagedAgentsSessionResourceNotFoundRunError as BetaManagedAgentsSessionResourceNotFoundRunError, type BetaManagedAgentsSkillNotFoundRunError as BetaManagedAgentsSkillNotFoundRunError, type BetaManagedAgentsTriggerContext as BetaManagedAgentsTriggerContext, type BetaManagedAgentsTriggerType as BetaManagedAgentsTriggerType, type BetaManagedAgentsUnknownRunError as BetaManagedAgentsUnknownRunError, type BetaManagedAgentsVaultArchivedRunError as BetaManagedAgentsVaultArchivedRunError, type BetaManagedAgentsVaultNotFoundRunError as BetaManagedAgentsVaultNotFoundRunError, type BetaManagedAgentsWorkspaceArchivedRunError as BetaManagedAgentsWorkspaceArchivedRunError, type BetaManagedAgentsDeploymentRunsPageCursor as BetaManagedAgentsDeploymentRunsPageCursor, type DeploymentRunRetrieveParams as DeploymentRunRetrieveParams, type DeploymentRunListParams as DeploymentRunListParams, };
}
//# sourceMappingURL=deployment-runs.d.mts.map