"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Versions = void 0;
const resource_1 = require("../../../core/resource.js");
const pagination_1 = require("../../../core/pagination.js");
const headers_1 = require("../../../internal/headers.js");
const uploads_1 = require("../../../internal/uploads.js");
const path_1 = require("../../../internal/utils/path.js");
class Versions extends resource_1.APIResource {
    /**
     * Create Skill Version
     *
     * @example
     * ```ts
     * const betaSkillVersion =
     *   await client.beta.skills.versions.create('skill_id', {
     *     files: [fs.createReadStream('path/to/file')],
     *   });
     * ```
     */
    create(skillID, params, options) {
        const { betas, workspace_id, ...body } = params;
        return this._client.post((0, path_1.path) `/v1/skills/${skillID}/versions?beta=true`, (0, uploads_1.multipartFormRequestOptions)({
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                {
                    ...(betas?.toString() != null ? { 'anthropic-beta': betas?.toString() } : undefined),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
        }, this._client, false));
    }
    /**
     * Get Skill Version
     *
     * @example
     * ```ts
     * const betaSkillVersion =
     *   await client.beta.skills.versions.retrieve('version', {
     *     skill_id: 'skill_id',
     *   });
     * ```
     */
    retrieve(version, params, options) {
        const { skill_id, betas, workspace_id } = params;
        return this._client.get((0, path_1.path) `/v1/skills/${skill_id}/versions/${version}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
                {
                    ...(betas?.toString() != null ? { 'anthropic-beta': betas?.toString() } : undefined),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
        });
    }
    /**
     * List Skill Versions
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaSkillVersion of client.beta.skills.versions.list(
     *   'skill_id',
     * )) {
     *   // ...
     * }
     * ```
     */
    list(skillID, params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path) `/v1/skills/${skillID}/versions?beta=true`, (pagination_1.PageCursor), {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
                {
                    ...(betas?.toString() != null ? { 'anthropic-beta': betas?.toString() } : undefined),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
        });
    }
    /**
     * Delete Skill Version
     *
     * @example
     * ```ts
     * const betaDeletedSkillVersion =
     *   await client.beta.skills.versions.delete('version', {
     *     skill_id: 'skill_id',
     *   });
     * ```
     */
    delete(version, params, options) {
        const { skill_id, betas, workspace_id } = params;
        return this._client.delete((0, path_1.path) `/v1/skills/${skill_id}/versions/${version}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
                {
                    ...(betas?.toString() != null ? { 'anthropic-beta': betas?.toString() } : undefined),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
        });
    }
    /**
     * Download a skill version's content as a zip archive.
     *
     * @example
     * ```ts
     * const response = await client.beta.skills.versions.download(
     *   'version',
     *   { skill_id: 'skill_id' },
     * );
     *
     * const content = await response.blob();
     * console.log(content);
     * ```
     */
    download(version, params, options) {
        const { skill_id, betas, workspace_id } = params;
        return this._client.get((0, path_1.path) `/v1/skills/${skill_id}/versions/${version}/content?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
                {
                    Accept: 'application/binary',
                    ...(betas?.toString() != null ? { 'anthropic-beta': betas?.toString() } : undefined),
                    ...(workspace_id != null ? { 'anthropic-workspace-id': workspace_id } : undefined),
                },
                options?.headers,
            ]),
            __binaryResponse: true,
        });
    }
}
exports.Versions = Versions;
//# sourceMappingURL=versions.js.map