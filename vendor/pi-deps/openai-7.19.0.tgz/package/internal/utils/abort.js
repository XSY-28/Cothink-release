"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.retainRequestAbortCallback = retainRequestAbortCallback;
exports.addRequestAbortListener = addRequestAbortListener;
// Keep these optional runtime features out of the SDK's ES2020 type requirements.
// SAFETY: These host features are optional and checked before use; the structural view avoids requiring newer ambient library declarations.
const weakGlobals = globalThis;
const finalizer = 
// oxlint-disable-next-line anti-slop/no-runtime-typeof -- Weak references and finalizers are optional host capabilities, so probe them before constructing either.
typeof weakGlobals.FinalizationRegistry === 'function'
    ? new weakGlobals.FinalizationRegistry((cleanup) => {
        try {
            cleanup();
        }
        catch {
            // Caller-provided signal methods must not throw out of a GC callback.
        }
    })
    : undefined;
const callbackOwners = new WeakMap();
const subscriptions = new WeakMap();
// This scope receives only a weak reference, so its closures cannot retain the callback.
function subscribeWeakly(signal, reference, registry) {
    let subscription = subscriptions.get(signal);
    if (!subscription) {
        const callbacks = new Set();
        const abort = () => {
            subscriptions.delete(signal);
            for (const callback of callbacks) {
                registry.unregister(callback);
                callback.deref()?.();
            }
            callbacks.clear();
        };
        subscription = { callbacks, abort };
        signal.addEventListener('abort', abort, { once: true });
        subscriptions.set(signal, subscription);
    }
    const owner = subscription;
    owner.callbacks.add(reference);
    return () => {
        owner.callbacks.delete(reference);
        registry.unregister(reference);
        if (owner.callbacks.size === 0) {
            if (subscriptions.get(signal) === owner) {
                subscriptions.delete(signal);
            }
            signal.removeEventListener('abort', owner.abort);
        }
    };
}
// The listener must not retain the shared owner or its other request callbacks.
function releaseOnAbort(signal, callbacks, abort) {
    signal.addEventListener('abort', () => callbacks.deref()?.delete(abort), { once: true });
}
/** Keep cancellation alive until abort or collection of the response body or bodyless custom response. */
function retainRequestAbortCallback(
// oxlint-disable-next-line anti-slop/no-object-parameters -- Abort callbacks are retained by any response-body or custom-response owner identity.
owner, abort, requestSignal) {
    // oxlint-disable-next-line anti-slop/no-runtime-typeof -- Weak references and finalizers are optional host capabilities, so probe them before constructing either.
    if (typeof weakGlobals.WeakRef === 'function' && finalizer && !requestSignal.aborted) {
        let callbacks = callbackOwners.get(owner);
        if (!callbacks) {
            callbacks = new Set();
            callbackOwners.set(owner, callbacks);
        }
        callbacks.add(abort);
        releaseOnAbort(requestSignal, new weakGlobals.WeakRef(callbacks), abort);
    }
}
/**
 * Share one caller listener without it retaining completed requests. Collection removes
 * weak subscriptions eventually; a live response body or custom response retains its callback.
 * Runtimes without weak references keep the existing listener-based behavior.
 */
function addRequestAbortListener(signal, abort, requestSignal) {
    if (signal.aborted) {
        abort();
        return () => {
            // No listener was installed for an already aborted signal.
        };
    }
    // oxlint-disable-next-line anti-slop/no-runtime-typeof -- Weak references and finalizers are optional host capabilities, so probe them before constructing either.
    if (typeof weakGlobals.WeakRef !== 'function' || !finalizer) {
        signal.addEventListener('abort', abort, { once: true });
        return () => signal.removeEventListener('abort', abort);
    }
    const reference = new weakGlobals.WeakRef(abort);
    const cleanup = subscribeWeakly(signal, reference, finalizer);
    finalizer.register(abort, cleanup, reference);
    retainRequestAbortCallback(requestSignal, abort, requestSignal);
    return cleanup;
}
//# sourceMappingURL=abort.js.map