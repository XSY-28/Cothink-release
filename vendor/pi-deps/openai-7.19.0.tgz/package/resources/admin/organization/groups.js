"use strict";
// File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("../../../internal/tslib.js");
tslib_1.__exportStar(require("./groups/index.js"), exports);
//# sourceMappingURL=groups.js.map