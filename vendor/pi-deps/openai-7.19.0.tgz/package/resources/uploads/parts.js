"use strict";
// File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Parts = void 0;
const resource_1 = require("../../core/resource.js");
const uploads_1 = require("../../internal/uploads.js");
const path_1 = require("../../internal/utils/path.js");
/**
 * Use Uploads to upload large files in multiple parts.
 */
class Parts extends resource_1.APIResource {
    /**
     * Adds a
     * [Part](https://developers.openai.com/api/reference/resources/uploads/subresources/parts)
     * to an [Upload](https://developers.openai.com/api/reference/resources/uploads)
     * object. A Part represents a chunk of bytes from the file you are trying to
     * upload.
     *
     * Each Part can be at most 64 MB, and you can add Parts until you hit the Upload
     * maximum of 8 GB.
     *
     * It is possible to add multiple Parts in parallel. You can decide the intended
     * order of the Parts when you
     * [complete the Upload](https://developers.openai.com/api/reference/resources/uploads/methods/complete).
     */
    create(uploadID, body, options) {
        return this._client.post((0, path_1.path) `/uploads/${uploadID}/parts`, (0, uploads_1.multipartFormRequestOptions)({ body, ...options, __security: { bearerAuth: true } }, this._client));
    }
}
exports.Parts = Parts;
//# sourceMappingURL=parts.js.map